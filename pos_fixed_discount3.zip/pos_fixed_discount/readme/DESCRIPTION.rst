In point of sale allow to apply discount with fixed amount.
