# -*- coding: utf-8 -*-
# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.

from . import report_barcode_product_labels
from . import report_barcode_product_temp_labels
from . import report_barcode_sale_labels
from . import report_barcode_purchase_labels
from . import report_barcode_stock_labels

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
